<?php
/**
 * @Author: ido_alit
 * @Date:   2015-11-15 22:23:14
 * @Last Modified by:   ido_alit
 * @Last Modified time: 2015-11-15 22:23:43
 */

echo '<div class="slims-card slims-card--default">';
// Chat Engine
include LIB."contents/chat.php";
echo '</div>';