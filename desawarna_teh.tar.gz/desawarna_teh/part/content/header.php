<!-- Header -->
<header id="header">
  <div class="intro text-center">
    <div class="overlay">
      <div class="container">
        <div class="row">
          <div class="intro-text">
            <h1 class="animated fadeInUp delay2"><?php echo $sysconf['library_name']; ?></h1>
            <p><?php echo $sysconf['library_subname']; ?></p>
            <a href="#services" class="btn btn-default btn-lg page-scroll">Layanan</a> </div>
        </div>
      </div>
    </div>
  </div>
</header>