<?php
/**
 * @Author: ido_alit
 * @Date:   2015-11-21 14:35:48
 * @Last Modified by:   ido_alit
 * @Last Modified time: 2015-11-21 17:40:10
 */

?>

<div class="slims-card slims-card--default">
	<div class="slims-card--header">
		<h4><?php echo __('License'); ?></h4>
	</div>
	<p>
		This software and this template are released Under <a href="http://www.gnu.org/copyleft/gpl.html" title="GNU GPL License" target="_blank">GNU GPL License</a> Version 3.
	</p>
</div>