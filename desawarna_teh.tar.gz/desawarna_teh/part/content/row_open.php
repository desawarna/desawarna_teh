<?php
/**
 * @Author: ido_alit
 * @Date:   2015-11-15 16:15:42
 * @Last Modified by:   ido_alit
 * @Last Modified time: 2015-11-15 16:16:14
 */

?>

<div class="slims-card slims-container container">