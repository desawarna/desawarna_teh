<div class="slims-card slims-card--default">
    <?php echo $search_result_info; ?>
</div>