    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="copyright">
            <p class="text-center"><small>A Free HTML5 Template by 
            <a href="http://freehtml5.co/">FREEHTML5.co</a>  &copy; 2017
            <br> Gratis SetUp SLiMS !!! Buat Website Di : <a href="http://desawarna.com">Desawarna.com</a></small></p>
          </div>
        </div>
      </div>
    </div>

    <!-- Back To Top -->
    <a href="javascript:void(0);" class="js-back-to-top back-to-top"><i class="fa fa-arrow-circle-up"></i></a>
  </footer>

</body>
</html>