  <main role="main" id="fh5co-main">
    <section class="feature">
      <div class="container">
        
        <div class="row">
          <div class="col-md-4">
            <div class="feature-item">
              <div class="feature-icon"><i class="fa fa-gift"></i></div>
              <div class="feature-text">
                <h3>Download for Free</h3>
                <p>Lorem ipsum dolor sit amet, <a href="#">consectetur</a> adipisicing elit. Quidem reiciendis consequuntur nisi enim similique officiis sint, in sequi iste repellat.</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="feature-item">
              <div class="feature-icon"><i class="fa fa-heart"></i></div>
              <div class="feature-text">
                <h3>Crafted with Love</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem reiciendis consequuntur nisi enim similique officiis sint, in sequi iste repellat.</p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="feature-item">
              <div class="feature-icon"><i class="fa fa-mobile"></i></div>
              <div class="feature-text">
                <h3>Mobile First</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem reiciendis consequuntur nisi enim similique officiis sint, in sequi iste repellat.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>