	<footer id="fh5co-footer" role="contentinfo">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-2 col-sm-4 col-xs-6">
					<h3>Halaman Cepat</h3>
					<ul class="fh5co-footer-links">
		              <li><a href="index.php?p=libinfo" >Info</a></li>
		              <li><a href="index.php?p=help" >Panduan Pengguna</a></li>
		              <li><a href="index.php?p=visitor" >Buku Tamu</a></li>
		              <li><a href="index.php?p=login" >Login Pustakawan</a></li>
		              <li><a href="index.php?p=member" >Login Anggota</a></li>
		              <li><a href="index.php?p=news" >Berita</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<h3>Koleksi Seru Kita</h3>
					<ul class="fh5co-footer-links">
		              <li><a href="index.php?search=search&title=&author=&subject=&isbn=&gmd=0&colltype=Fiction&location=0&search=search" >Fiksi</a></li>
		              <li><a href="index.php?search=search&title=&author=&subject=&isbn=&gmd=0&colltype=Reference&location=0&search=search" >Referensi</a></li>
		              <li><a href="index.php?search=search&title=&author=&subject=&isbn=&gmd=0&colltype=Textbook&location=0&search=search" >Buku Tekstual</a></li>
		              <li><a href="index.php?keywords=komik&search=search" >Komik</a></li>
					</ul>
				</div>

				<div class="col-md-2 col-sm-4 col-xs-6">
					<h3>Panduan Publik</h3>
					<ul class="fh5co-footer-links">
						<li><a href="#">FAQ</a></li>
						<li><a href="#">Peraturan</a></li>
						<li><a href="#">Hak Public</a></li>
						<li><a href="#">Layanan</a></li>
					</ul>
				</div>
				<div class="col-md-4 col-sm-12 col-xs-12 fh5co-widget col-md-push-1">
					<h3>Template Desawarna</h3>
					<p>Kami berharap Template SLiMS ini dapat dimanfaatkan dengan sebaik-baiknya sebagai template SLiMS bagi semua SLiMerS, serta mampu memberikan dukungan dalam pencapaian tujuan pengembangan perpustakaan dan kearsipan.. Aamiin</p>
					<p><a href="http://desawarna.com">Selengkapnya <i class="fa fa-play"></i></a></p>
				</div>
			</div>

			<div class="row copyright">
				<div class="col-md-12 text-center">
					<p>
						<small class="block">&copy; 2017 Free HTML5. All Rights Reserved.</small> 
						<small class="block">Designed by <a href="http://freehtml5.co/" target="_blank">FreeHTML5.co</a> Porting Ke SLiMS Oleh : <a href="http://desawarna.com/" target="_blank">DESAWARNA.COM</a></small>
					</p>
					<p>
						<ul class="fh5co-social-icons">
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
							<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
						</ul>
					</p>
				</div>
			</div>

		</div>
	</footer>
	</div>