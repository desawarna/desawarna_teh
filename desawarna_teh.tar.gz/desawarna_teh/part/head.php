<?php
/**
 * @Author: ido_alit
 * @Modified : Zaemakhrus , pada tanggal 30 Desember 2017
 * @Date:   2015-11-12 18:46:45
 * @Last Modified by:   ido_alit
 * @Last Modified time: 2015-11-24 09:35:03
 */
?>

<!DOCTYPE html>
<html>
<head>
	<title><?php echo $page_title; ?></title>

	<?php 
	// load meta modified from default template
	include 'meta.php';
	?>
</head>
<body id="slims-page">
<!-- // wraper -->
<div class="page-wraper">
