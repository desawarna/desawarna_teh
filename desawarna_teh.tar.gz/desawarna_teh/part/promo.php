<div id="promo">
	<div class="container text-center">
    	<div class="col-md-8 col-md-offset-2">
		<p> Gratis SetUp SLiMS !!! Buat Website Di : <a href="http://desawarna.com">Desawarna.com</a></p>
		</div>
	</div>
</div>

<div class="gototop js-top">
	<a href="javascript:void(0);" class="js-back-to-top back-to-top"><i class="fa fa-arrow-circle-up"></i></a>
</div>

</body>
</html>